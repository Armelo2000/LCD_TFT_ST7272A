/*
 * menu.h
 *
 *  Created on: Mar 19, 2023
 *      Author: melah
 */

#ifndef MENU_H_
#define MENU_H_

#include "lvgl/lvgl.h"
#include "Display_Menu/battery.h"

typedef enum{
	BLOCK_MAX_SPEED = 0,
	BLOCK_AVG_SPEED,
	BLOCK_TOT_DISTANCE,
	BLOCK_RANGE
}block_role_t;

struct userDefBlock {
    lv_obj_t* obj;
    lv_obj_t* labelText;
    lv_obj_t* labelValue;
    lv_obj_t* labelUnit;
    block_role_t role;
};

typedef struct userDefBlock	user_block_t;

typedef struct board_display{
	lv_obj_t* display;
	user_block_t** blockField;
	BatteryBlock_t* batteryBlock;
	lv_obj_t* circle;
	lv_obj_t* sport;
	lv_obj_t* drive;
	lv_obj_t* eco;
	lv_style_t* style_mode_on;
	lv_style_t* style_mode_off;
	lv_obj_t* labelcurrentSpeed;
	lv_obj_t* labelSpeedUnit;

}board_display_t;

void createBlock(user_block_t* block, const char* text, const char* unit,
				 uint32_t width, uint32_t height);

void setBlock_bg_color(lv_obj_t* obj, uint32_t color);
void setText_color(lv_obj_t* obj, uint32_t color);
void alignTo(user_block_t* block, lv_obj_t* base, lv_align_t align,
			 lv_coord_t x_offset, lv_coord_t y_offset);

static void set_value(void* indic, int32_t v);

void lv_example_meter_car_1(void);
void lv_ex_obj_1(void);

board_display_t* create_board_display();

void createBatteryBlock(user_block_t* block, uint32_t width, uint32_t height);
#endif /* MENU_H_ */
