/*
 * menu.c
 *
 *  Created on: Mar 19, 2023
 *      Author: melah
 */

#include "Display_Menu/menu.h"

static lv_obj_t* meter;
static lv_meter_indicator_t* indic;
static lv_obj_t* label, *speed;
lv_obj_t* display;

static board_display_t board_display;
static BatteryBlock_t battery_icon;
user_block_t maxSpeed, avgSpeed, totDistance, range;


void createBlock(user_block_t* block, const char* text, const char* unit,
				 uint32_t width, uint32_t height) {
	//Pointer check
	if(block == (user_block_t *)0) return;

    block->obj = lv_obj_create(lv_scr_act());
    block->labelText = lv_label_create(lv_scr_act());
    block->labelValue = lv_label_create(lv_scr_act());
    block->labelUnit = lv_label_create(lv_scr_act());

    lv_obj_set_size(block->obj, width, height);
    //lv_obj_align(block->obj, LV_ALIGN_CENTER, 0, 0);
    //lv_obj_align_to(block->obj, display, LV_ALIGN_TOP_LEFT, 0, -10);
    //lv_obj_center(obj);
    lv_obj_set_style_bg_color(block->obj, lv_color_hex(0x000000), 0);

    lv_obj_set_size(block->labelText, 100, 40);
    lv_obj_set_size(block->labelValue, 100, 40);
    lv_obj_set_size(block->labelUnit, 100, 40);

    static lv_style_t style, style_big;

    lv_style_init(&style);
    lv_style_init(&style_big);

    lv_style_set_text_font(&style, &lv_font_montserrat_10); // <--- you have to enable other font sizes in menuconfig
    lv_style_set_text_font(&style_big, &lv_font_montserrat_14);
    lv_obj_add_style(block->labelText, &style, 0);
    lv_obj_add_style(block->labelValue, &style_big, 0);
    lv_obj_add_style(block->labelUnit, &style, 0);

    lv_label_set_text(block->labelText, text);
    lv_label_set_text(block->labelValue, "27899");
    lv_label_set_text(block->labelUnit, unit);
    lv_obj_align_to(block->labelText, block->obj, LV_ALIGN_TOP_MID, 20, -10);
    //lv_obj_align_to(block->labelValue, block->obj, LV_ALIGN_TOP_RIGHT, 30, 13);
    //lv_obj_align_to(block->labelUnit, block->labelValue, LV_ALIGN_RIGHT_MID, 50, 3);
    lv_obj_align_to(block->labelValue, block->labelText, LV_ALIGN_BOTTOM_MID, -5, 15);
    lv_obj_align_to(block->labelUnit, block->labelValue, LV_ALIGN_RIGHT_MID, 50, 5);

    lv_obj_set_style_bg_color(lv_scr_act(), lv_color_hex(0xffffff), LV_PART_MAIN);
    lv_obj_set_style_text_color(lv_scr_act(), lv_color_hex(0xffffff), LV_PART_MAIN);
};

void createBatteryBlock(user_block_t* block, uint32_t width, uint32_t height) {
	//Pointer check
	if(block == (user_block_t *)0) return;

	lv_obj_t* tmp = lv_obj_create(lv_scr_act());
    block->obj = lv_obj_create(lv_scr_act());

    lv_obj_t* battery_0_25 = lv_obj_create(lv_scr_act());
    lv_obj_t* battery_25_50 = lv_obj_create(lv_scr_act());
    lv_obj_t* battery_50_75 = lv_obj_create(lv_scr_act());
    lv_obj_t* battery_75_100 = lv_obj_create(lv_scr_act());

    lv_obj_set_size(battery_0_25, 16, 7);
    lv_obj_set_size(battery_25_50, 16, 7);
    lv_obj_set_size(battery_50_75, 16, 7);
    lv_obj_set_size(battery_75_100, 16, 7);
    lv_obj_set_size(block->obj, 20, 35);
	lv_obj_set_size(tmp, 8, 16);

    lv_obj_set_scrollbar_mode(battery_0_25, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_25_50, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_50_75, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_75_100, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(block->obj, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(tmp, LV_SCROLLBAR_MODE_OFF);

    //lv_obj_align(block->obj, LV_ALIGN_CENTER, 0, 0);
    //lv_obj_align_to(block->obj, display, LV_ALIGN_TOP_LEFT, 0, -10);
    //lv_obj_center(obj);
    lv_obj_set_style_bg_color(block->obj, lv_color_hex(0x000000), 0);
    lv_obj_set_style_bg_color(tmp, lv_color_hex(0x000000), 0);

    lv_obj_align(block->obj, LV_ALIGN_CENTER, 0, 0);
    lv_obj_align_to(tmp, block->obj, LV_ALIGN_OUT_TOP_MID, 0, 8);
    lv_obj_align_to(battery_0_25, block->obj, LV_ALIGN_OUT_BOTTOM_MID, 0, -9);
    lv_obj_align_to(battery_25_50, battery_0_25, LV_ALIGN_OUT_TOP_MID, 0, -1);
    lv_obj_align_to(battery_50_75, battery_25_50, LV_ALIGN_OUT_TOP_MID, 0, -1);
    lv_obj_align_to(battery_75_100, battery_50_75, LV_ALIGN_OUT_TOP_MID, 0, -1);

    static lv_style_t style, bgColorBlack, bgColorWhite;

    lv_style_init(&style);
    lv_style_init(&bgColorBlack);
    lv_style_init(&bgColorWhite);
    lv_style_set_border_color(&style, lv_color_hex(0xffffff));
    lv_style_set_bg_color(&bgColorBlack, lv_color_hex(0x000000));
    lv_style_set_bg_color(&bgColorWhite, lv_color_hex(0xFFFFFF));
    lv_style_set_border_color(&bgColorBlack, lv_color_hex(0x000000));
    lv_style_set_border_color(&bgColorWhite, lv_color_hex(0xFFFFFF));

    //lv_style_set_text_font(&style, &lv_font_montserrat_10); // <--- you have to enable other font sizes in menuconfig
    lv_style_set_radius(&style, 2);
    lv_style_set_radius(&bgColorBlack, 1);
    lv_style_set_radius(&bgColorWhite, 1);

    lv_obj_add_style(block->obj, &style, 0);
    lv_obj_add_style(tmp, &style, 0);
    uint8_t status = 0;
    if(status == 100){
        lv_obj_add_style(battery_75_100, &bgColorWhite, 0);
        lv_obj_add_style(battery_50_75, &bgColorWhite, 0);
        lv_obj_add_style(battery_25_50, &bgColorWhite, 0);
        lv_obj_add_style(battery_0_25, &bgColorWhite, 0);

    }else if(status == 75){
        lv_obj_add_style(battery_75_100, &bgColorBlack, 0);
        lv_obj_add_style(battery_50_75, &bgColorWhite, 0);
        lv_obj_add_style(battery_25_50, &bgColorWhite, 0);
        lv_obj_add_style(battery_0_25, &bgColorWhite, 0);

    }else if(status == 50){
        lv_obj_add_style(battery_75_100, &bgColorBlack, 0);
        lv_obj_add_style(battery_50_75, &bgColorBlack, 0);
        lv_obj_add_style(battery_25_50, &bgColorWhite, 0);
        lv_obj_add_style(battery_0_25, &bgColorWhite, 0);

    }else if(status == 25){
        lv_obj_add_style(battery_75_100, &bgColorBlack, 0);
        lv_obj_add_style(battery_50_75, &bgColorBlack, 0);
        lv_obj_add_style(battery_25_50, &bgColorBlack, 0);
        lv_obj_add_style(battery_0_25, &bgColorWhite, 0);
    }else if(status == 0){
        lv_obj_add_style(battery_75_100, &bgColorBlack, 0);
        lv_obj_add_style(battery_50_75, &bgColorBlack, 0);
        lv_obj_add_style(battery_25_50, &bgColorBlack, 0);
        lv_obj_add_style(battery_0_25, &bgColorBlack, 0);
    }

    lv_obj_set_style_bg_color(lv_scr_act(), lv_color_hex(0x000000), LV_PART_MAIN);
    //lv_obj_set_style_text_color(lv_scr_act(), lv_color_hex(0xffffff), LV_PART_MAIN);
};

void setBlock_bg_color(lv_obj_t* obj, uint32_t color) {
    lv_obj_set_style_text_color(obj, lv_color_hex(color), LV_PART_MAIN);
};
void setText_color(lv_obj_t* obj, uint32_t color) {
    lv_obj_set_style_text_color(obj, lv_color_hex(color), LV_PART_MAIN);
};
void alignTo(user_block_t* block, lv_obj_t* base, lv_align_t align,
			 lv_coord_t x_offset, lv_coord_t y_offset) {

	if(block == (user_block_t*)0) return;

    lv_obj_align_to(block->obj, base, align, x_offset, y_offset);
    lv_obj_align_to(block->labelText, block->obj, LV_ALIGN_TOP_MID, 20, -10);
    lv_obj_align_to(block->labelValue, block->labelText, LV_ALIGN_BOTTOM_MID, -5, 15);
    lv_obj_align_to(block->labelUnit, block->labelValue, LV_ALIGN_RIGHT_MID, 50, 5);
}


static void set_value(void* indic, int32_t v)
{
    if(meter != NULL)
    	lv_meter_set_indicator_value(meter, (lv_meter_indicator_t*)indic, v);
}

/**
 * A simple meter
 */
void lv_example_meter_car_1(void)
{

    display = lv_obj_create(lv_scr_act());
    lv_obj_set_size(display, 240, 320);

    lv_obj_set_style_bg_color(lv_scr_act(), lv_color_hex(0x000000), LV_PART_MAIN);
    lv_obj_set_style_bg_color(display, lv_color_hex(0x000000), LV_PART_MAIN);

    //lv_obj_center(display);
    lv_obj_align_to(display, lv_scr_act(), LV_ALIGN_TOP_MID, 0, 0);





    //meter = lv_meter_create(lv_scr_act());
   // lv_obj_center(meter);
    //lv_obj_set_size(meter, 150, 150);
    //lv_obj_set_style_bg_color(meter, lv_color_hex(0x0FF0FF), LV_PART_MAIN);

    lv_obj_t * cont = lv_obj_create(lv_scr_act());
    lv_obj_center(cont);
      lv_obj_set_size(cont, 150, 150);
      lv_obj_set_style_radius(cont, LV_RADIUS_CIRCLE, 0);

      //lv_obj_set_flex_flow(cont, LV_FLEX_FLOW_COLUMN);
      //lv_obj_add_event(cont, scroll_event_cb, LV_EVENT_SCROLL, NULL);

      //lv_obj_set_style_clip_corner(cont, true, 0);
      //lv_obj_set_scroll_dir(cont, LV_DIR_VER);
      //lv_obj_set_scroll_snap_y(cont, LV_SCROLL_SNAP_CENTER);
      //lv_obj_set_scrollbar_mode(cont, LV_SCROLLBAR_MODE_OFF);
      lv_obj_set_style_bg_color(cont, lv_color_hex(0x000000), LV_PART_MAIN);
/*
    // Add a scale first
    lv_meter_set_scale_ticks(meter, 41, 2, 10, lv_palette_main(LV_PALETTE_GREY));
    lv_meter_set_scale_major_ticks(meter, 8, 4, 15, lv_color_black(), 10);

    //Add a blue arc to the start
    indic = lv_meter_add_arc(meter, 3, lv_palette_main(LV_PALETTE_BLUE), 0);
    lv_meter_set_indicator_start_value(meter, indic, 0);
    lv_meter_set_indicator_end_value(meter, indic, 20);

    // Make the tick lines blue at the start of the scale
    indic = lv_meter_add_scale_lines(meter, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_BLUE),
        false, 0);
    lv_meter_set_indicator_start_value(meter, indic, 0);
    lv_meter_set_indicator_end_value(meter, indic, 20);

    // Add a red arc to the end
    indic = lv_meter_add_arc(meter, 3, lv_palette_main(LV_PALETTE_RED), 0);
    lv_meter_set_indicator_start_value(meter, indic, 80);
    lv_meter_set_indicator_end_value(meter, indic, 100);

    // Make the tick lines red at the end of the scale
    indic = lv_meter_add_scale_lines(meter, lv_palette_main(LV_PALETTE_RED), lv_palette_main(LV_PALETTE_RED), false,
        0);
    lv_meter_set_indicator_start_value(meter, indic, 80);
    lv_meter_set_indicator_end_value(meter, indic, 100);

    // Add a needle line indicator
    indic = lv_meter_add_needle_line(meter, 4, lv_palette_main(LV_PALETTE_GREY), -10);

    /*Create an animation to set the value*/
    /*
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_exec_cb(&a, set_value);
    lv_anim_set_var(&a, indic);
    lv_anim_set_values(&a, 0, 100);
    lv_anim_set_time(&a, 2000);
    lv_anim_set_repeat_delay(&a, 100);
    lv_anim_set_playback_time(&a, 500);
    lv_anim_set_playback_delay(&a, 100);
    lv_anim_set_repeat_count(&a, LV_ANIM_REPEAT_INFINITE);
    lv_anim_start(&a);
    */
    //lv_obj_t* label = lv_label_create(lv_scr_act());
    //lv_obj_t* speed = lv_label_create(lv_scr_act());
/*
    lv_obj_t* grad = lv_obj_create(lv_scr_act());
    lv_obj_set_size(grad, MASK_WIDTH, MASK_HEIGHT);
    lv_obj_center(grad);
    lv_obj_set_style_bg_color(grad, lv_color_hex(0xf5f5f5), 0);

    lv_obj_set_size(label, 100, 60);
    lv_obj_set_size(speed, 100, 60);
    lv_label_set_text(label, "Km/h");
    lv_obj_align_to(label, meter, LV_ALIGN_OUT_BOTTOM_MID, 32, -20);
    lv_obj_align_to(speed, label, LV_ALIGN_OUT_TOP_MID, 12, 40);
*/

    lv_obj_t* eco, *drive, *sport;

    createBlock(&maxSpeed,"Max Speed", "Km/h", 100, 40);
    createBlock(&avgSpeed, "Avg Speed", "Km/h", 100, 40);
    createBlock(&totDistance, "Tot Distance", "Km", 100, 40);
    createBlock(&range, "Range", "Km", 100, 40);

    //
    eco = lv_label_create(lv_scr_act());
    drive = lv_label_create(lv_scr_act());
    sport = lv_label_create(lv_scr_act());

    lv_obj_set_size(eco, 50, 20);
    lv_label_set_text(eco, "ECO");

    lv_obj_set_size(drive, 55, 20);
	lv_label_set_text(drive, "DRIVE");

	lv_obj_set_size(sport, 60, 20);
	lv_label_set_text(sport, "SPORT");

	lv_obj_align_to(eco, display, LV_ALIGN_BOTTOM_LEFT, 5, 5);
	lv_obj_align_to(drive, eco, LV_ALIGN_OUT_RIGHT_MID, 15, 0);
	lv_obj_align_to(sport, drive, LV_ALIGN_OUT_RIGHT_MID, 20, 0);

	static lv_style_t style_mode, text_right;
	lv_style_init(&style_mode);
	lv_style_init(&text_right);
	lv_style_set_radius(&style_mode, 5);
	lv_style_set_border_width(&style_mode, 1);
	lv_style_set_border_color(&style_mode, lv_palette_main(LV_PALETTE_RED));
	lv_style_set_text_align(&style_mode, LV_TEXT_ALIGN_CENTER);
	lv_style_set_text_align(&text_right, LV_TEXT_ALIGN_CENTER);
	//lv_label_set_align(eco, LV_ALIGN_CENTER);
	//lv_obj_add_style(eco, &style_mode, 0);
	//lv_obj_add_style(drive, &style_mode, 0);
	lv_obj_add_style(sport, &style_mode, 0);

    //
    alignTo(&maxSpeed, display, LV_ALIGN_TOP_LEFT, 0, -5);
    alignTo(&avgSpeed, maxSpeed.obj, LV_ALIGN_OUT_RIGHT_MID, 5, 0);
    alignTo(&totDistance, maxSpeed.obj, LV_ALIGN_OUT_BOTTOM_MID, 0, 5);
    alignTo(&range, totDistance.obj, LV_ALIGN_OUT_RIGHT_MID, 5, 0);
    //lv_obj_align_to(meter, display, LV_ALIGN_TOP_MID, 0, 115);
    //lv_obj_align_to(c.labelValue, c.labelUnit, LV_ALIGN_CENTER, 10, 0);
    lv_obj_align_to(range.labelText, range.obj, LV_ALIGN_CENTER, 30, 5);

    lv_obj_align_to(cont, totDistance.obj, LV_ALIGN_OUT_BOTTOM_MID, 0, 0);
    lv_obj_align_to(cont, display, LV_ALIGN_CENTER, 0, 15);

/*
    LV_IMG_DECLARE(batterie4x_100px);

    static lv_style_t style;
    lv_style_init(&style);
    lv_style_set_bg_color(&style, lv_palette_main(LV_PALETTE_YELLOW));
    lv_style_set_bg_opa(&style, LV_OPA_COVER);
    //lv_style_set_img_recolor_opa(&style, LV_OPA_COVER);
    //lv_style_set_img_recolor(&style, lv_color_black());

    lv_obj_t * img = lv_img_create(lv_scr_act());
    lv_obj_add_style(img, &style, 0);
    lv_img_set_src(img, &batterie4x_100px);
    lv_obj_set_size(img, 50, 50);
    lv_obj_center(img);
*/
    static lv_style_t battery_style;
    lv_style_init(&battery_style);
    lv_style_set_bg_color(&battery_style, lv_palette_main(LV_PALETTE_RED));
    lv_style_set_border_color(&battery_style, lv_palette_main(LV_PALETTE_RED));

    lv_obj_t* battery_head = lv_obj_create(lv_scr_act());
    lv_obj_t* battery = lv_obj_create(lv_scr_act());
    lv_obj_t* battery_0_25 = lv_obj_create(lv_scr_act());
    lv_obj_t* battery_25_50 = lv_obj_create(lv_scr_act());
    lv_obj_t* battery_50_75 = lv_obj_create(lv_scr_act());
    lv_obj_t* battery_75_100 = lv_obj_create(lv_scr_act());


    lv_obj_set_size(battery_0_25, 25, 10);
    lv_obj_set_size(battery_25_50, 25, 10);
    lv_obj_set_size(battery_50_75, 25, 10);
    lv_obj_set_size(battery_75_100, 25, 10);
    lv_obj_set_size(battery_head, 8, 8);
    lv_obj_set_size(battery, 25, 45);
    lv_obj_set_scrollbar_mode(battery, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_0_25, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_25_50, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_50_75, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_75_100, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery_head, LV_SCROLLBAR_MODE_OFF);
    //lv_obj_align_to(battery_0_25, cont, LV_ALIGN_LEFT_MID, 50, 0);
    lv_obj_align_to(battery, cont, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_align_to(battery_0_25, battery, LV_ALIGN_OUT_BOTTOM_MID, 0, -11);
    lv_obj_align_to(battery_25_50, battery_0_25, LV_ALIGN_OUT_TOP_MID, 0, -1);
    lv_obj_align_to(battery_50_75, battery_25_50, LV_ALIGN_OUT_TOP_MID, 0, -1);
    lv_obj_align_to(battery_75_100, battery_50_75, LV_ALIGN_OUT_TOP_MID, 0, -1);
    lv_obj_align_to(battery_head, battery, LV_ALIGN_OUT_TOP_MID, 0, 0);
    lv_obj_add_style(battery_0_25, &battery_style, 0);
    lv_obj_add_style(battery_25_50, &battery_style, 0);
    lv_obj_add_style(battery_50_75, &battery_style, 0);
    lv_obj_add_style(battery_75_100, &battery_style, 0);
    //lv_label_set_recolor(battery_0_25, 1);

 /*
    lv_obj_t * bar1 = lv_bar_create(lv_scr_act());
    lv_obj_set_size(bar1, 200, 20);
    lv_obj_align(bar1, LV_ALIGN_CENTER, 0, 0);
    //lv_bar_set_anim_time(bar1, 2000);
    lv_bar_set_value(bar1, 100, LV_ANIM_ON);
*/

    //setText_color(c.labelValue, 0x00FF00);
    lv_obj_set_size(maxSpeed.labelValue, 50, 30);
    lv_obj_set_size(avgSpeed.labelValue, 50, 30);

    lv_obj_set_size(totDistance.labelValue, 50, 50);
	lv_obj_set_size(range.labelValue, 50, 50);

    lv_label_set_text(maxSpeed.labelValue, "60890");
    lv_label_set_text(avgSpeed.labelValue, "45");

    lv_obj_add_style(maxSpeed.labelValue, &text_right, 0);
    lv_obj_add_style(avgSpeed.labelValue, &text_right, 0);

    lv_obj_add_style(totDistance.labelValue, &text_right, 0);
    lv_obj_add_style(range.labelValue, &text_right, 0);

    lv_obj_set_scrollbar_mode(lv_scr_act(), LV_SCROLLBAR_MODE_OFF);
}


void lv_ex_obj_1(void)
{
    lv_obj_t * obj1;
    obj1 = lv_obj_create(lv_scr_act());
    lv_obj_set_size(obj1, 100, 50);
    lv_obj_align(obj1, LV_ALIGN_CENTER, -60, -30);

    /*Copy the previous object and enable drag*/
    lv_obj_t * obj2;
    obj2 = lv_obj_create(lv_scr_act());
    lv_obj_align(obj2, LV_ALIGN_CENTER, 0, 0);
    //lv_obj_set_drag(obj2, true);

    static lv_style_t style_shadow;
    lv_style_init(&style_shadow);
    lv_style_set_shadow_width(&style_shadow, 10);
    lv_style_set_shadow_spread(&style_shadow, 5);
    //lv_style_set_shadow_color(&style_shadow, LV_COLOR_BLUE);

    /*Copy the previous object (drag is already enabled)*/
    lv_obj_t * obj3;
    obj3 = lv_obj_create(lv_scr_act());
    lv_obj_add_style(obj3, &style_shadow, 0);
    lv_obj_align(obj3, LV_ALIGN_CENTER, 60, 30);
}

/*****************************************************************
 * This function create a menu board with 4 block at the top of
 * the display a circle with the current speed the battery icon
 *
 *****************************************************************/
board_display_t* create_board_display(){

	board_display_t* ptBoardDisplay = &board_display;
	//BatteryBlock_t* ptBatteryIcon = &battery_icon;
	static lv_style_t style_mode_on, style_mode_off, text_right, sizeSpeed, sizeSpeedUnit;

	//configure the 240x320 pixel display
	ptBoardDisplay->display = lv_obj_create(lv_scr_act());
    lv_obj_set_size(ptBoardDisplay->display, 240, 320);

    lv_obj_set_style_bg_color(lv_scr_act(), lv_color_hex(0x000000), LV_PART_MAIN);
    lv_obj_set_style_bg_color(ptBoardDisplay->display, lv_color_hex(0x000000), LV_PART_MAIN);
    lv_obj_align_to(ptBoardDisplay->display, lv_scr_act(), LV_ALIGN_TOP_MID, 0, 0);

    //configure the circle where the current speed is displayed
    ptBoardDisplay->circle = lv_obj_create(lv_scr_act());
	lv_obj_center(ptBoardDisplay->circle);
	lv_obj_set_size(ptBoardDisplay->circle, 200, 150);
	lv_obj_set_style_radius(ptBoardDisplay->circle, LV_RADIUS_CIRCLE, 0);
	lv_obj_set_style_bg_color(ptBoardDisplay->circle, lv_color_hex(0x000000), LV_PART_MAIN);

    //Speed label on Board computer
    ptBoardDisplay->labelSpeedUnit = lv_label_create(lv_scr_act());
    ptBoardDisplay->labelcurrentSpeed = lv_label_create(lv_scr_act());
    lv_style_init(&sizeSpeed);
    lv_style_init(&sizeSpeedUnit);
    //set the font for the battery value
    lv_style_set_text_font(&sizeSpeed, &lv_font_montserrat_32);
    lv_style_set_text_font(&sizeSpeedUnit, &lv_font_montserrat_12);
    lv_obj_add_style(ptBoardDisplay->labelcurrentSpeed, &sizeSpeed, 0);
    lv_obj_add_style(ptBoardDisplay->labelSpeedUnit, &sizeSpeedUnit, 0);
    lv_label_set_text(ptBoardDisplay->labelSpeedUnit, "Km/h");

    lv_obj_align_to(ptBoardDisplay->labelcurrentSpeed, ptBoardDisplay->circle, LV_ALIGN_CENTER, 0, 10);
    lv_obj_align_to(ptBoardDisplay->labelSpeedUnit, ptBoardDisplay->labelcurrentSpeed, LV_ALIGN_OUT_RIGHT_MID, 0, 0);

    //TODO (LVGL) This is a test
    lv_label_set_text(ptBoardDisplay->labelcurrentSpeed, "100");
	//This is  the Battery icon
	// Align all objects and sub-objects
	 ptBoardDisplay->batteryBlock = createBattery();
	 lv_obj_align_to(ptBoardDisplay->batteryBlock->obj, ptBoardDisplay->circle, LV_ALIGN_LEFT_MID, 0, 8);
	 lv_obj_align_to(ptBoardDisplay->batteryBlock->labelValue, ptBoardDisplay->batteryBlock->obj, LV_ALIGN_OUT_BOTTOM_MID, 0, 0);

	 lv_obj_align_to(ptBoardDisplay->batteryBlock->head, ptBoardDisplay->batteryBlock->obj, LV_ALIGN_OUT_TOP_MID, 0, 11);
	 lv_obj_align_to(ptBoardDisplay->batteryBlock->bat_0_25, ptBoardDisplay->batteryBlock->obj, LV_ALIGN_OUT_BOTTOM_MID, 0, -9);
	 lv_obj_align_to(ptBoardDisplay->batteryBlock->bat_25_50, ptBoardDisplay->batteryBlock->bat_0_25, LV_ALIGN_OUT_TOP_MID, 0, -1);
	 lv_obj_align_to(ptBoardDisplay->batteryBlock->bat_50_75, ptBoardDisplay->batteryBlock->bat_25_50, LV_ALIGN_OUT_TOP_MID, 0, -1);
	 lv_obj_align_to(ptBoardDisplay->batteryBlock->bat_75_100, ptBoardDisplay->batteryBlock->bat_50_75, LV_ALIGN_OUT_TOP_MID, 0, -1);


	 //setBatteryStatus(bat, BATTERY_25_PERCENT);

	//create 4 blocks
	user_block_t* blockField[4] = {
			(user_block_t *)&maxSpeed,
			(user_block_t *)&avgSpeed,
			(user_block_t *)&totDistance,
			(user_block_t *)&range,
	};

	//set role for each block
	maxSpeed.role = BLOCK_MAX_SPEED;
	avgSpeed.role = BLOCK_AVG_SPEED;
	totDistance.role = BLOCK_TOT_DISTANCE;
	range.role = BLOCK_RANGE;

	ptBoardDisplay->blockField = blockField;

    createBlock(&maxSpeed,"Max Speed", "Km/h", 100, 40);
    createBlock(&avgSpeed, "Avg Speed", "Km/h", 100, 40);
    createBlock(&totDistance, "Tot Distance", "Km", 100, 40);
    createBlock(&range, "Range", "Km", 100, 40);

    ptBoardDisplay->eco = lv_label_create(lv_scr_act());
    ptBoardDisplay->drive = lv_label_create(lv_scr_act());
    ptBoardDisplay->sport = lv_label_create(lv_scr_act());

	lv_obj_set_size(ptBoardDisplay->eco, 50, 20);
	lv_label_set_text(ptBoardDisplay->eco, "ECO");

	lv_obj_set_size(ptBoardDisplay->drive, 55, 20);
	lv_label_set_text(ptBoardDisplay->drive, "DRIVE");

	lv_obj_set_size(ptBoardDisplay->sport, 60, 20);
	lv_label_set_text(ptBoardDisplay->sport, "SPORT");

	lv_obj_align_to(ptBoardDisplay->eco, ptBoardDisplay->display, LV_ALIGN_BOTTOM_LEFT, 5, 5);
	lv_obj_align_to(ptBoardDisplay->drive, ptBoardDisplay->eco, LV_ALIGN_OUT_RIGHT_MID, 15, 0);
	lv_obj_align_to(ptBoardDisplay->sport, ptBoardDisplay->drive, LV_ALIGN_OUT_RIGHT_MID, 20, 0);

	//init styles
	lv_style_init(&style_mode_on);
	lv_style_init(&style_mode_off);
	lv_style_init(&text_right);
	lv_style_set_radius(&style_mode_on, 5);
	lv_style_set_radius(&style_mode_off, 5);
	lv_style_set_border_width(&style_mode_on, 1);
	lv_style_set_border_width(&style_mode_off, 1);
	lv_style_set_border_color(&style_mode_on, lv_palette_main(LV_PALETTE_RED));
	lv_style_set_border_color(&style_mode_off, lv_palette_main(LV_PALETTE_RED));
	lv_style_set_text_align(&style_mode_on, LV_TEXT_ALIGN_CENTER);
	lv_style_set_text_align(&style_mode_off, LV_TEXT_ALIGN_CENTER);
	lv_style_set_text_align(&text_right, LV_TEXT_ALIGN_CENTER);
	ptBoardDisplay->style_mode_on = &style_mode_on;
	ptBoardDisplay->style_mode_off = &style_mode_off;
	//lv_label_set_align(eco, LV_ALIGN_CENTER);
	//lv_obj_add_style(ptBoardDisplay->eco, ptBoardDisplay->style_mode_off, 0);
	//lv_obj_add_style(ptBoardDisplay->drive, ptBoardDisplay->style_mode_off, 0);
	lv_obj_add_style(ptBoardDisplay->sport, ptBoardDisplay->style_mode_on, 0);

    //
    alignTo(&maxSpeed, ptBoardDisplay->display, LV_ALIGN_TOP_LEFT, 0, -5);
    alignTo(&avgSpeed, maxSpeed.obj, LV_ALIGN_OUT_RIGHT_MID, 5, 0);
    alignTo(&totDistance, maxSpeed.obj, LV_ALIGN_OUT_BOTTOM_MID, 0, 5);
    alignTo(&range, totDistance.obj, LV_ALIGN_OUT_RIGHT_MID, 5, 0);
    //lv_obj_align_to(meter, display, LV_ALIGN_TOP_MID, 0, 115);
    //lv_obj_align_to(c.labelValue, c.labelUnit, LV_ALIGN_CENTER, 10, 0);
    lv_obj_align_to(range.labelText, range.obj, LV_ALIGN_CENTER, 30, 5);

    lv_obj_align_to(ptBoardDisplay->circle, totDistance.obj, LV_ALIGN_OUT_BOTTOM_MID, 0, 0);
    lv_obj_align_to(ptBoardDisplay->circle, ptBoardDisplay->display, LV_ALIGN_CENTER, 0, 15);


    lv_obj_set_size(maxSpeed.labelValue, 50, 30);
    lv_obj_set_size(avgSpeed.labelValue, 50, 30);

    lv_obj_set_size(totDistance.labelValue, 50, 50);
	lv_obj_set_size(range.labelValue, 50, 50);

    lv_label_set_text(maxSpeed.labelValue, "80");
    lv_label_set_text(avgSpeed.labelValue, "45");

    lv_obj_add_style(maxSpeed.labelValue, &text_right, 0);
    lv_obj_add_style(avgSpeed.labelValue, &text_right, 0);

    lv_obj_add_style(totDistance.labelValue, &text_right, 0);
    lv_obj_add_style(range.labelValue, &text_right, 0);

    lv_obj_set_scrollbar_mode(lv_scr_act(), LV_SCROLLBAR_MODE_OFF);

	return ptBoardDisplay;
}
