/*
 * ST7272A.c
 *
 *  Created on: Mar 31, 2023
 *      Author: tsa
 */
#include "ST7272A.h"

void st7272a_set_bgr() {
  uint8_t lcd_bgr[2] = {ST7272A_DISPLAY_MODE_REGISTER, ST7272A_DISPLAY_MODE_DEFAULT | 0b00010000}; // Set the SBGR bit to swap DR[7:0] with DB[7:0]
  LCD_IO_ST7272_Write(*((uint16_t *)lcd_bgr));
}
