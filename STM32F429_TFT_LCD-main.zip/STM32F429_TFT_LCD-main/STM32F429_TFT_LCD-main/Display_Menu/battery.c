/*
 * battery.c
 *
 *  Created on: 26.03.2023
 *      Author: melah
 *
 *      This file is the implementation of the Battery icon that should be
 *      display with 5 different charging levels (0% 25% 50% 75% 100%).
 */


#include "Display_Menu/battery.h"

static BatteryBlock_t battery;

BatteryBlock_t* createBattery(){

	static lv_style_t style, bgColorBlack, bgColorWhite, batValue;

	// create objects for the Battery icon
	battery.head = lv_obj_create(lv_scr_act());
	battery.obj = lv_obj_create(lv_scr_act());
	battery.labelValue = lv_label_create(lv_scr_act());

    battery.bat_0_25 = lv_obj_create(lv_scr_act());
    battery.bat_25_50 = lv_obj_create(lv_scr_act());
    battery.bat_50_75 = lv_obj_create(lv_scr_act());
    battery.bat_75_100 = lv_obj_create(lv_scr_act());

    // Set size of each block in the battery
    lv_obj_set_size(battery.bat_0_25, 16, 7);
    lv_obj_set_size(battery.bat_25_50, 16, 7);
    lv_obj_set_size(battery.bat_50_75, 16, 7);
    lv_obj_set_size(battery.bat_75_100, 16, 7);
    lv_obj_set_size(battery.obj, 20, 35);
	lv_obj_set_size(battery.head, 8, 16);
	lv_obj_set_size(battery.labelValue, 35, 14);

	// Scrollbar deactivate
    lv_obj_set_scrollbar_mode(battery.bat_0_25, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery.bat_25_50, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery.bat_50_75, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery.bat_75_100, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery.obj, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_scrollbar_mode(battery.head, LV_SCROLLBAR_MODE_OFF);

    //background color of both objects that should be assemble
    lv_obj_set_style_bg_color(battery.obj, lv_color_hex(0x000000), 0);
	lv_obj_set_style_bg_color(battery.head, lv_color_hex(0x000000), 0);

	// Align all objects and sub-objects
	//lv_obj_align(battery.obj, LV_ALIGN_CENTER, 0, 0);
	//lv_obj_align_to(battery.head, battery.obj, LV_ALIGN_OUT_TOP_MID, 0, 11);
	//lv_obj_align_to(battery.bat_0_25, battery.obj, LV_ALIGN_OUT_BOTTOM_MID, 0, -9);
	//lv_obj_align_to(battery.bat_25_50, battery.bat_0_25, LV_ALIGN_OUT_TOP_MID, 0, -1);
	//lv_obj_align_to(battery.bat_50_75, battery.bat_25_50, LV_ALIGN_OUT_TOP_MID, 0, -1);
	//lv_obj_align_to(battery.bat_75_100, battery.bat_50_75, LV_ALIGN_OUT_TOP_MID, 0, -1);

	//Initialize the style
    lv_style_init(&style);
    lv_style_init(&bgColorBlack);
    lv_style_init(&bgColorWhite);
    lv_style_init(&batValue);

    //set the font for the battery value
    lv_style_set_text_font(&batValue, &lv_font_montserrat_10);
    lv_style_set_text_align(&batValue, LV_TEXT_ALIGN_CENTER);

    // Set Black color
    lv_style_set_bg_color(&bgColorBlack, lv_color_hex(0x000000));
	lv_style_set_border_color(&bgColorBlack, lv_color_hex(0x000000));
	// Set White color
	lv_style_set_bg_color(&bgColorWhite, lv_color_hex(0xFFFFFF));
	lv_style_set_border_color(&bgColorWhite, lv_color_hex(0xFFFFFF));

    lv_style_set_border_color(&style, lv_color_hex(0xffffff));

    //The blocks are rounded with the radius value of 2 and 1 respectively
    lv_style_set_radius(&style, 2);
    lv_style_set_radius(&bgColorBlack, 1);
    lv_style_set_radius(&bgColorWhite, 1);

    battery.black = &bgColorBlack;
    battery.white = &bgColorWhite;

    // a Style
    lv_obj_add_style(battery.obj, &style, 0);
	lv_obj_add_style(battery.head, &style, 0);
	lv_obj_add_style(battery.labelValue, &batValue, 0);


	return &battery;
}

static void setBattery_0_Percent(BatteryBlock_t *bat){
	if(bat == (BatteryBlock_t *)0) return;

	lv_obj_add_style(bat->bat_75_100, bat->black, 0);
	lv_obj_add_style(bat->bat_50_75, bat->black, 0);
	lv_obj_add_style(bat->bat_25_50, bat->black, 0);
	lv_obj_add_style(bat->bat_0_25, bat->black, 0);
}

static void setBattery_25_Percent(BatteryBlock_t *bat){
	if(bat == (BatteryBlock_t *)0) return;

	lv_obj_add_style(bat->bat_75_100, bat->black, 0);
	lv_obj_add_style(bat->bat_50_75, bat->black, 0);
	lv_obj_add_style(bat->bat_25_50, bat->black, 0);
	lv_obj_add_style(bat->bat_0_25, bat->white, 0);
}

static void setBattery_50_Percent(BatteryBlock_t *bat){
	if(bat == (BatteryBlock_t *)0) return;

	lv_obj_add_style(bat->bat_75_100, bat->black, 0);
	lv_obj_add_style(bat->bat_50_75, bat->black, 0);
	lv_obj_add_style(bat->bat_25_50, bat->white, 0);
	lv_obj_add_style(bat->bat_0_25, bat->white, 0);
}

static void setBattery_75_Percent(BatteryBlock_t *bat){
	if(bat == (BatteryBlock_t *)0) return;

	lv_obj_add_style(bat->bat_75_100, bat->black, 0);
	lv_obj_add_style(bat->bat_50_75, bat->white, 0);
	lv_obj_add_style(bat->bat_25_50, bat->white, 0);
	lv_obj_add_style(bat->bat_0_25, bat->white, 0);
}

static void setBattery_100_Percent(BatteryBlock_t *bat){
	if(bat == (BatteryBlock_t *)0) return;

	lv_obj_add_style(bat->bat_75_100, bat->white, 0);
	lv_obj_add_style(bat->bat_50_75, bat->white, 0);
	lv_obj_add_style(bat->bat_25_50, bat->white, 0);
	lv_obj_add_style(bat->bat_0_25, bat->white, 0);
}

void setBatteryStatus(BatteryBlock_t* bat, battery_level_t level){
	if(bat == (BatteryBlock_t *)0) return;

	switch(level){
	case BATTERY_0_PERCENT:
		setBattery_0_Percent(bat);
		break;
	case BATTERY_25_PERCENT:
		setBattery_25_Percent(bat);
		break;
	case BATTERY_50_PERCENT:
		setBattery_50_Percent(bat);
		break;
	case BATTERY_75_PERCENT:
		setBattery_75_Percent(bat);
		break;
	case BATTERY_100_PERCENT:
		setBattery_100_Percent(bat);
		break;

	default:
		break;
	}
}

void setBatteryValue(BatteryBlock_t* bat, uint8_t value){
	if(bat == (BatteryBlock_t *)0) return;

	char valArray[5] = {'\0'};
	uint8_t size = convertIntToCharArry(value, valArray);
	if((size == 0) || (size > 3)) return;

	valArray[size] = '%';
	valArray[size + 1] = '\0';

	lv_label_set_text(bat->labelValue, valArray);
	if(value < 10){
		setBatteryStatus(bat, BATTERY_0_PERCENT);
	}else if(value < 35){
		setBatteryStatus(bat, BATTERY_25_PERCENT);
	}else if(value < 60){
		setBatteryStatus(bat, BATTERY_50_PERCENT);
	}else if(value < 90){
		setBatteryStatus(bat, BATTERY_75_PERCENT);
	}else{
		setBatteryStatus(bat, BATTERY_100_PERCENT);
	}

}

uint8_t convertIntToCharArry(unsigned int hex, char* ptChar){
	if(ptChar == (char *)0) return 0;
	int i;
	char ch;
	uint8_t cnt = 0;
	char tmp[10];

	do{
		ch = hex % 10;

		tmp[cnt++] = ch + 0x30;

		hex = hex / 10;


	}while(hex != 0);

	for(i=0; i<cnt; i++){
		ptChar[i] = tmp[cnt - i - 1];
	}

	return cnt;
}
