/*
 * battery.h
 *
 *  Created on: 26.03.2023
 *      Author: melah
 */

#ifndef BATTERY_H_
#define BATTERY_H_


#include "lvgl/lvgl.h"

enum{
	BATTERY_0_PERCENT = 0,
	BATTERY_25_PERCENT = 25,
	BATTERY_50_PERCENT = 50,
	BATTERY_75_PERCENT = 75,
	BATTERY_100_PERCENT = 100
};

typedef uint8_t battery_level_t;

typedef struct BatteryBlock {
    lv_obj_t* obj;
    lv_obj_t* labelValue;
    lv_obj_t* head;

    // These are the positions of the battery bar (in %)
    lv_obj_t* bat_0_25;
    lv_obj_t* bat_25_50;
    lv_obj_t* bat_50_75;
    lv_obj_t* bat_75_100;

    //style
    lv_style_t* black;
    lv_style_t* white;

}BatteryBlock_t;

BatteryBlock_t* createBattery();

static void setBattery_0_Percent(BatteryBlock_t *bat);
static void setBattery_25_Percent(BatteryBlock_t *bat);
static void setBattery_50_Percent(BatteryBlock_t *bat);
static void setBattery_75_Percent(BatteryBlock_t *bat);
static void setBattery_100_Percent(BatteryBlock_t *bat);

void setBatteryStatus(BatteryBlock_t* bat, battery_level_t level);
void setBatteryValue(BatteryBlock_t* bat, uint8_t value);
uint8_t convertIntToCharArry(unsigned int hex, char* ptChar);

#endif /* BATTERY_H_ */
