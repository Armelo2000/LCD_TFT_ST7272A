/*
 * ST7272A.h
 *
 *  Created on: Mar 31, 2023
 *      Author: tsa
 */

#ifndef TFT_ST7272A_H_
#define TFT_ST7272A_H_

#include "hal_stm_lvgl/stm32f429i_discovery.h"

#define ST7272A_DISPLAY_MODE_REGISTER 0x19
#define ST7272A_DISPLAY_MODE_DEFAULT  0xec  // 0b11101100 VA Mode, Top/Bottom & Left/Right scan, Negative polarity VSync/HSync pulses


//#define LCD_CS_GPIO_Port
//#define LCD_CS_Pin

//#define HIGH(PORT, PIN) HAL_GPIO_WritePin(PORT, PIN, GPIO_PIN_SET);
//#define LOW(PORT, PIN) HAL_GPIO_WritePin(PORT, PIN, GPIO_PIN_RESET);

//#define ST7272A_CS(active)            if(active) {LOW(LCD_CS_GPIO_Port, LCD_CS_Pin)} else {HIGH(LCD_CS_GPIO_Port, LCD_CS_Pin)}
//#define ST7272A_RESET()               LOW(LCD_RESET_GPIO_Port, LCD_RESET_Pin); HAL_Delay(100); HIGH(LCD_RESET_GPIO_Port, LCD_RESET_Pin); HAL_Delay(100);


extern void st7272a_set_bgr();

#endif /* TFT_ST7272A_H_ */
